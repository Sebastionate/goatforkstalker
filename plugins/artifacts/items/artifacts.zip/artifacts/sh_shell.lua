ITEM.name = "Shell"
ITEM.model = "models/nasca/etherealsrp_artifacts/shell.mdl"
ITEM.description = "Blue, semit-ransparent artifact."
ITEM.longdesc = "Formerly considered to be useless, this artifact was discovered to stimulate the nervous system when kept in constant contact with the body. It helps to replenish the energy of its user.\n\n+10 Reflex"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 31000
ITEM.flag = "A"
ITEM.isArtefact = true
ITEM.rads = 2

ITEM.buffs = {
	["reflex"] = 10,
}
